#include"temps.h"


int conver(tps t){
	return(t.heures*60+t.minutes);
}

