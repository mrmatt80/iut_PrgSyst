#include<stdlib.h>
#include<stdio.h>

typedef struct tps{
int minutes;
int heures;
}tps, *teps;


teps somme(tps t1,tps t2);

int conver(tps t);
